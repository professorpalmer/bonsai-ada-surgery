| family | task | raw | layer | rescues / losses (B vs A) |
| --- | --- | ---: | ---: | --- |
| coding | suite-tar-01 | 0/4 | 2/4 | 2 / 0 |
| coding | xfer-mime-01 | 1/4 | 1/4 | 1 / 1 |
| coding | xfer-zip-01 | 1/4 | 4/4 | 3 / 0 |
| computation | digits | 0/3 | 3/3 | 3 / 0 |
| computation | knapsack | 3/3 | 3/3 | 0 / 0 |
| computation | lcs | 0/3 | 2/3 | 2 / 0 |
| computation | sales | 1/3 | 3/3 | 2 / 0 |
| computation | weblog | 3/3 | 3/3 | 0 / 0 |
| workspace | chain | 2/2 | 2/2 | 0 / 0 |
| workspace | copy | 1/2 | 1/2 | 0 / 0 |
| workspace | dedupeH | 2/2 | 1/2 | 0 / 1 |
| workspace | invoiceH | 2/2 | 2/2 | 0 / 0 |
| workspace | ledgerH | 1/2 | 1/2 | 0 / 0 |
| **total** | | **17/37** | **28/37** | **13 / 2** |

completion tokens: raw 777,825, layer 572,550
